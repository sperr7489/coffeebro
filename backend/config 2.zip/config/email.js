const userProvider = require("../Router/User/userProvider");
const userService = require("../Router/User/userService");
const nodemailer = require("nodemailer");
const { basicResponse, resultResponse } = require("./response");
const baseResponseStatus = require("./baseResponseStatus");
const regex = require("./regex");

// 최상단 폴더에서 path를 설정해주었다면 그 하위 폴더에서는 config() 만해주면 된.
// require("dotenv").config();

const { ADMIN_EMAIL, ADMIN_PASSWD } = process.env;

/* min ~ max까지 랜덤으로 숫자를 생성하는 함수 */
const generateRandom = function (min, max) {
  const ranNum = Math.floor(Math.random() * (max - min + 1)) + min;
  return ranNum;
};

const transporter = nodemailer.createTransport({
  service: "Naver",
  host: "smtp.naver.com",
  port: 587,
  auth: {
    // 이메일을 보낼 계정 데이터 입력
    user: ADMIN_EMAIL,
    pass: ADMIN_PASSWD,
  },
});

// 이메일 인증
exports.emailValidation = async (req, res) => {
  //3개에 대해서 body로 그 값을 받아와준다.
  const { email } = req.body;
  const emailVal = await regex.email(email);

  if (!emailVal) {
    return res.send(basicResponse(baseResponseStatus.EMAIL_AJOU_FALSE));
  }
  const validationNum = generateRandom(111111, 999999);

  if (!email) {
    return res.send(basicResponse(baseResponseStatus.PARAMS_NOT_EXACT));
  }
  //이메일 중복 검사
  const emailCheck = await userProvider.emailCheck(email);
  if (emailCheck) {
    return res.send(basicResponse(baseResponseStatus.EMAIL_EXISTS));
  }

  const emailOptions = {
    // 옵션값 설정
    from: ADMIN_EMAIL,
    to: email,
    subject: "[coffeeBro] 회원가입 인증 코드입니다. ",
    text:
      " 이 인증 코드 6자리를 회원가입 이메일 인증 칸에 입력해주세요\n" +
      validationNum,
  };

  // res 값으로 이메일 인증 코드를 보내고 클라이언트에서 번호를 비교하여 인증 처리 완료시킨다.
  transporter.sendMail(emailOptions, (err, info) => {
    if (err) {
      return res.send(basicResponse(baseResponseStatus.EMAIL_TRANSPORT_ERROR));
    } else {
      return res
        .status(200)
        .send(resultResponse(baseResponseStatus.SUCCESS, validationNum));
    }
  });
};
