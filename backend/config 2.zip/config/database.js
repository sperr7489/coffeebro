const mysql = require("mysql2/promise");

// RDS
// const pool = mysql.createPool({
//   host: "coffeebrords.crwmccplwfrt.ap-northeast-2.rds.amazonaws.com",
//   port: "3306",
//   user: "admin",
//   password: "coffeebro12!",
//   database: "coffeebroRds",
// });

// 로컬
const pool = mysql.createPool({
  host: "127.0.0.1",
  port: "3306",
  user: "root",
  password: "Rlarlckd12!",
  database: "coffeebroRds",
});

module.exports = {
  pool,
};
